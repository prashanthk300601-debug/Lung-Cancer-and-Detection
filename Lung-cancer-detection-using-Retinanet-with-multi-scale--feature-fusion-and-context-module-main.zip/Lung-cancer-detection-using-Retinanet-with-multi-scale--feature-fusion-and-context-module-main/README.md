# Lung-cancer-detection-using-Retinanet-with-multi-scale--feature-fusion-and-context-module
• Developed an advanced deep learning model for early detection of lung cancer from CT scans using RetinaNet.
